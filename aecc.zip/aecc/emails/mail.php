<?php
echo "export SENDGRID_API_KEY='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'" > sendgrid.env
echo "sendgrid.env" >> .gitignore
source ./sendgrid.env

require 'vendor/autoload.php'; // If you're using Composer (recommended)
// Comment out the above line if not using Composer
require("./'24 AECC Website/sendgrid-php.php");
// If not using Composer, uncomment the above line and
// download sendgrid-php.zip from the latest release here,
// replacing <PATH TO> with the path to the sendgrid-php.php file,
// which is included in the download:
// https://github.com/sendgrid/sendgrid-php/releases

$email = new \SendGrid\Mail\Mail(); 
$email->setFrom($_POST['email'], $_POST['name']);
$email->setSubject("Sending with SendGrid is Fun");
$email->addTo('aecc.uprb@upr.edu', 'AECC ACM Chapter');
$email->addContent("text/plain", "and easy to do anywhere, even with PHP");
$email->addContent(
    "text/html", "<strong>and easy to do anywhere, even with PHP</strong>"
);
$sendgrid = new \SendGrid(getenv('SENDGRID_API_KEY'));
try {
    $response = $sendgrid->send($email);
    print $response->statusCode() . "\n";
    print_r($response->headers());
    print $response->body() . "\n";
} catch (Exception $e) {
    echo 'Caught exception: '. $e->getMessage() ."\n";
}




/* //** ini_set('display_errors', true);

    if (isset($_POST) && !empty($_POST)) {
        // foreach ($_POST as $key => $value) {
        //     echo $key." >> ".$value."<br>";
        // }
        // die();
        require ('/var/www/html/cs2/aecc/ext/PHPMailer-master/PHPMailerAutoload.php');
        
        $mail = new PHPMailer;
        $mail->isSMTP();                                    // Set mailer to use SMTP
    
        // $mail->SMTPDebug = 2;                               // Enable verbose debug output
        // $mail->Debugoutput = 'html';
    
        $mail->Host         = 'smtp.gmail.com';                      // Specify main and backup SMTP servers
        $mail->SMTPAuth     = true;                               // Enable SMTP authentication
        $mail->Username     = 'aecc.uprb@upr.edu';                 // SMTP username
        $mail->Password     = 'aecc6107';                         // SMTP password
        $mail->SMTPSecure   = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port         = 587;                                    // TCP port to connect to
        $mail->SMTPDebug = 2;

        $mail->setFrom($_POST['email'], $_POST['name']);
        $mail->addAddress('aecc.uprb@upr.edu', 'AECC ACM Chapter');
        $mail->addCC($_POST['email'], $_POST['name']);
        $mail->addReplyTo('taiana.avila@upr.edu', 'Taiana Avila');
    
        // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    
        $mail->isHTML(true); 
        
        $mail->Subject = $_POST['subject'];
        $mail->Body    = $_POST['message'];
        // $mail->AltBody = '';
    
        // $mail->AddStringAttachment();
    
        if( !$mail->send() ) {
            //NO SE ENVIÓ
            echo "MESSAGE NOT SENT";
            die();    
        }
        header("Location: MessageSuccessfully.html");
    } else {
        echo "POST ERROR";
    } // */
?>